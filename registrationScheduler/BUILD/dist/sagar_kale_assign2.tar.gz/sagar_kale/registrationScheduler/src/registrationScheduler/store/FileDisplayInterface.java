package registrationScheduler.store;

/**
 * FileDisplay Interface with method to write schedules to file.
 * @author Sagar
 *
 */
public interface FileDisplayInterface {
	public void writeSchedulestoFile();
}
