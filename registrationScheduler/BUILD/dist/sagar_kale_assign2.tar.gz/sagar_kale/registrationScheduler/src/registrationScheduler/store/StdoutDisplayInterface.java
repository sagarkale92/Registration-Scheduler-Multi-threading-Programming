package registrationScheduler.store;

/**
 * StdoutDisplay Interface with method to write schedules to screen.
 * @author Sagar
 *
 */
public interface StdoutDisplayInterface {
	public void writeSchedulesToScreen();
}
